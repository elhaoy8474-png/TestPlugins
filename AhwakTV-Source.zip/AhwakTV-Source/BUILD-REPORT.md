# تقرير بناء AhwakTV
- Commit: eb455041e7790d9ceabd99ada37d701924758515
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44340203993
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
