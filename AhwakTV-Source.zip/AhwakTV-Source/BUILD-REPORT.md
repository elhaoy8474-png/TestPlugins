# تقرير بناء AhwakTV
- Commit: a88b85625edb0f93288c8d524eb96f73fa3c3544
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44341192044
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
