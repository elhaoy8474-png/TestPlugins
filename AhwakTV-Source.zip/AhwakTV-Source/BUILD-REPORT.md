# تقرير بناء AhwakTV
- Commit: b5cb42a0bb45a6076bbe8ca3401626586dfbe7a0
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44352204323
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
