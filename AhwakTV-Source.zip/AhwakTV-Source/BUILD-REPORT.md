# تقرير بناء AhwakTV
- Commit: 46539a76faa276227defe5910c5ccec4d01c0106
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45667137393
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
