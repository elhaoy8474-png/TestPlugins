# تقرير بناء AhwakTV
- Commit: f90962e8bdc64de6630ff92fe652362416217480
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44296030064
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
