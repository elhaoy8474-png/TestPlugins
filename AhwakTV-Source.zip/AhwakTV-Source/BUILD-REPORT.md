# تقرير بناء AhwakTV
- Commit: c7d33b8c0abbfef2f867913772a5a3fe20a3a6d8
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45247428512
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
