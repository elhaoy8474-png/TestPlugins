# تقرير بناء AhwakTV
- Commit: f9d7e6fd603683c2ba7acd55fdc8468e9b593f34
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43696695224
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
