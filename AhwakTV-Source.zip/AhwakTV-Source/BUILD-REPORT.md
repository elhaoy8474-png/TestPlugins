# تقرير بناء AhwakTV
- Commit: f0c0fb8371826b7f865516b658a3aadfa0b49e62
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43700863251
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
