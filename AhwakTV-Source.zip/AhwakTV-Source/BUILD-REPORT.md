# تقرير بناء AhwakTV
- Commit: 11851572d31cc88e70f1dd1f747e67e4158112cd
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44332071093
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
