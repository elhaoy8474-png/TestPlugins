# تقرير بناء AhwakTV
- Commit: 1823e356c27f361efeda05249a9d13e001613c12
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43697555590
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
