# تقرير بناء AhwakTV
- Commit: bff73e75018ac19fdc7ba1d8941c3cabfdf93ad7
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44351456515
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
