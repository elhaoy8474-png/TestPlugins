# تقرير بناء AhwakTV
- Commit: 756832b41a6e9c626c59e3c03c48d95d364bb446
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44297230324
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
