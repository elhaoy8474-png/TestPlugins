# تقرير بناء AhwakTV
- Commit: 9ed928599eb9a879744f86200362a91d2c754765
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45666640187
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
