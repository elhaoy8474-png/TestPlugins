# تقرير بناء AhwakTV
- Commit: ea6328c0f026e4fe6af8a7f850a30161c6ccfc69
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44344311296
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
