# تقرير بناء AhwakTV
- Commit: 5ca9db8480d913eb991612b34312c46d081c5838
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43698146333
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
