# تقرير بناء AhwakTV
- Commit: aae292f8c2d798a6153387e11fc87961a0fd5207
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45781335381
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
