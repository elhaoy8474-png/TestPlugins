# تقرير بناء AhwakTV
- Commit: 38ed93cfa8352a07b8c70c098e3ff3e9305fdbe6
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43698771716
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
