# تقرير بناء AhwakTV
- Commit: 944fa6e8a378e369861c0e5a70b8d90b7a219b12
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43699786726
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
