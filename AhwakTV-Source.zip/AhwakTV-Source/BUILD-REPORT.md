# تقرير بناء AhwakTV
- Commit: 7f2d0cf0f40f58f5e5a6a79c45ff5b22d185a5db
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45787121444
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
