# تقرير بناء AhwakTV
- Commit: 0ba65ae11a7490940fbaf2b7795c83e952e471db
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43699126769
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
