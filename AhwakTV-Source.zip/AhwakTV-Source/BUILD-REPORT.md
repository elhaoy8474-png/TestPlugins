# تقرير بناء AhwakTV
- Commit: f84fb4429a3326721faa7cb56a71fbd969002246
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44363695281
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
