# تقرير بناء AhwakTV
- Commit: 9d3f13161296e7b4695bbc43517dbf5ff51fcc73
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44324676311
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
