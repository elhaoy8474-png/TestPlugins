# تقرير بناء AhwakTV
- Commit: 636f76f0396c1381c1326cb78045519c8dbdc387
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43702867790
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
