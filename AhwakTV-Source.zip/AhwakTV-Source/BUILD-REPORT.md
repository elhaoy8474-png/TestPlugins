# تقرير بناء AhwakTV
- Commit: 0356eb46e496d810367c70e5e174474a68e9f2ea
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44326946280
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
