# تقرير بناء AhwakTV
- Commit: f779aa8773cb053d3e3435949c6a317a23fdf13a
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44915700289
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
