# تقرير بناء AhwakTV
- Commit: 1af46621fa2127725679aa1d7c6aba0038ab4b03
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45732005024
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
