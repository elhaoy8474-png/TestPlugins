# تقرير بناء AhwakTV
- Commit: fc6c0f0bd3e967a4ae4ed97de4bb216a9adafd3e
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45252098454
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
