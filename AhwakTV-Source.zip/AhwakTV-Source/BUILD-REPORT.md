# تقرير بناء AhwakTV
- Commit: 8f8ab1eaafca74754b15a2570faa5bb6739854dd
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44297627234
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
