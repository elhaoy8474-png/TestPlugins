# تقرير بناء AhwakTV
- Commit: 6f45de79c15f8e57461ee2d4d8797c9cbff5a8fa
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44306004713
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
