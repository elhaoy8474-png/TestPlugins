# تقرير بناء AhwakTV
- Commit: 8e2259b36b45098f5bf4dd1949434f8d6be3017b
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45252232350
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
