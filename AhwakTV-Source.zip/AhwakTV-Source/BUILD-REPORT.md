# تقرير بناء AhwakTV
- Commit: a2839fcc467dc4ff3197715c4b942113fbd5a989
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43701627518
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
