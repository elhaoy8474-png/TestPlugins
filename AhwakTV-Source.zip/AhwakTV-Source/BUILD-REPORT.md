# تقرير بناء AhwakTV
- Commit: 2a28adc98515fb24da8cd727e2a505e6fe894579
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/44330346909
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
