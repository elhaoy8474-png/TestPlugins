# تقرير بناء AhwakTV
- Commit: f74ed806bf4764e26ce2c7cf3b3da2775542c6ca
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/45247074587
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
