# تقرير بناء AhwakTV
- Commit: 7556b39c94f0b438db243b8cae494b63840c9b44
- Workflow: https://github.com/elhaoy8474-png/TestPlugins/actions/runs/43700481433
- Build: Gradle tasks make and makePluginsJson
- Runtime playback: not verified by CI; test on KodaStream is still required.
