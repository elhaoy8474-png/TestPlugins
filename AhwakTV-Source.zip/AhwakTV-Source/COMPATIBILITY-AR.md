# مراجعة توافق KodaStream

تمت مراجعة أرشيف cloudSTREAM3-main.zip مباشرةً. القيم الموجودة في مشروع المضيف:
- Gradle Wrapper: 9.4.1
- Android Gradle Plugin: 9.1.1
- Kotlin Gradle Plugin: 2.4.0
- هدف JVM في مكتبة المضيف: 11

واجهات المصدر التي تمت مراجعتها:
- MainAPI: getMainPage(page, request), search(query, page), quickSearch(query), load(url)، وloadLinks(data, isCasting, subtitleCallback, callback).
- BasePlugin: registerMainAPI(MainAPI) وregisterExtractorAPI(ExtractorApi).
- ExtractorApi: getUrl(url, referer, subtitleCallback, callback)، كما يوفر المضيف loadExtractor(url, referer, subtitleCallback, callback).
- PluginManager: يتوقع ملف .cs3 يحتوي classes.dex وmanifest.json، ثم يقرأ pluginClassName وrequiresResources ويحمل الصنف عبر PathClassLoader.

نقطة مهمة عن الاختبار: بناء هذه الإضافة تم عبر قالب CloudStream للإضافات (Gradle 8.12 وAGP 8.7.3 وKotlin 2.4.0، مع اعتماد cloudstream3 pre-release). تمت مطابقة توقيعات API مع مصدر KodaStream المرفق، لكن البناء لم يكن مشروع Gradle فرعياً داخل نسخة KodaStream نفسها؛ لذلك يلزم تثبيت .cs3 واختباره على التطبيق الفعلي لإثبات التوافق وقت التشغيل.
