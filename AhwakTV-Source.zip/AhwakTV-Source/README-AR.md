# إضافة AhwakTV

مشروع مصدر مستقل لإضافة أهواك تي في المتوافقة مع واجهة CloudStream التي يستخدمها KodaStream.

## البناء
- JDK 17
- Gradle Wrapper 8.12 المرفق
- Android SDK Platform 35 وBuild Tools 35
- Android Gradle Plugin 8.7.3 وKotlin Gradle Plugin 2.4.0 كما في ملف البناء المرجعي

من جذر المشروع نفّذ:
```bash
./gradlew --no-daemon :AhwakTV:make
```

لإعادة بناء كل الإضافات وإنشاء قائمة المستودع:
```bash
./gradlew --no-daemon make makePluginsJson
```

ينتج ملف `.cs3` داخل مجلد بناء وحدة AhwakTV. يتم توليد `manifest.json` داخل الحزمة بواسطة إضافة Gradle من التعليمة `@CloudstreamPlugin` على الصنف `com.ahwaktv.AhwakTVPlugin`.

## إضافة المستودع إلى KodaStream
استخدم رابط المستودع:
`https://raw.githubusercontent.com/elhaoy8474-png/TestPlugins/builds/repo.json`

## النطاق
- الصفحة الرئيسية، قائمة المسلسلات، الجديد، والأكثر مشاهدة.
- فهرس التصنيفات وصفحات التصنيف.
- البحث عبر نموذج البحث الذي يقدمه الموقع إذا كان موجوداً في الصفحة.
- تفاصيل المسلسل والحلقات والمواسم، مع تجميع الحلقات بحسب اسم المسلسل وترتيبها رقمياً.
- استخراج روابط الفيديو العامة الظاهرة في عناصر iframe/video/source، وتمرير مشغلات التضمين إلى ExtractorApi المسجل في التطبيق.
- لا تتجاوز الإضافة تسجيل الدخول أو CAPTCHA أو أي قيود وصول، ولا تنشئ روابط تشغيل غير موجودة في الصفحة.

## حالة الاختبار
نجاح بناء Gradle والتحقق من إنشاء ملف `.cs3` وقائمة `plugins.json` لا يثبت وحده أن كل خادم فيديو يعمل داخل التطبيق. يلزم اختبار تشغيل فعلي على KodaStream مع صفحة/حلقة متاحة.
